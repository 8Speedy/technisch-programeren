﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mediaan
{
    public partial class Mediaan: Form
    {
        private List<int> numbers = new List<int>();

        public Mediaan()
        {
            InitializeComponent();
        }

        private void buttonBerekenen_Click(object sender, EventArgs e)
        {
            int number = (int)numericMediaanInput.Value;
            numbers.Add(number);
            numbers.Sort();
            double mediaan = BerekenMediaan();
            labelMediaan.Text = mediaan.ToString();
        }   

        private double BerekenMediaan()
        {
            int optellen = numbers.Count();
            if (optellen == 0) return 0;
            if (optellen % 2 == 1)
            {
                return numbers[optellen / 2];
            }
            else
            {
                return (numbers[(optellen / 2) - 1] + numbers[optellen / 2]) / 2.0;
            }
        }
    }
}
