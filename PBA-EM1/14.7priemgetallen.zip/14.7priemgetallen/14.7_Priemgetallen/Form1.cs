namespace _14._7_Priemgetallen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int getal = (int)Invoer.Value;
            int Aantal = 0;

            for (int i = 1; i <= getal; i++)
            {
                int Rest = getal % i;
                if (Rest == 0)
                {
                    Aantal = Aantal + 1;
                }
            }

            if (Aantal == 2)
            {
                Uitvoer.Text = "Priemgetal!";
            }
            else
            {
                Uitvoer.Text = "Geen priemgetal!";
            }



        }

        private void Invoer_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}