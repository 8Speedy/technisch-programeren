﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Shooter
{
    public partial class ShooterGame : Form
    {
        public ShooterGame()
        {
            InitializeComponent();
        }

        int highscore = 0;
        int totaal = 0;

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void SusClick(object sender, EventArgs e)
        {
            const int plus = 1;
            totaal = totaal + plus;

            labelScoreOut.Text = totaal.ToString();
            if (totaal> highscore)
            {
                highscore = totaal;
            }
            labelHighscoreOut.Text = highscore.ToString();



        }

        private void timer1_Tick(object sender, EventArgs e)
        {       
            int minx = 0;
            int maxx = pictureBackground.Width - imageSus.Width;
            int miny = 100;
            int maxy = pictureBackground.Height - imageSus.Height;

            if (minx > maxx) { maxx = 0; }
            if (miny > maxy) { maxy = 0; }

            Random random = new Random();
            int willekeurigGetal = random.Next(minx, maxx );

            if(maxy < miny)
            {
                maxy = miny;
            }

            int willekeurigGetal2 = random.Next(miny, maxy);
            imageSus.Location = new Point(willekeurigGetal, willekeurigGetal2);
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timerTijd.Interval = 100;

            if (tijdover > 0)
            {
                tijdover = tijdover - 0.1;
                labelTimeLeftOut.Text = tijdover.ToString("F1") + " seconden";
            }
            else
            {
                timerShooter.Stop();
                labelTimeLeftOut.Text = "Tijd is over!";
                imageSus.Visible = false;
                buttonStop.Visible = false;
                buttonStart.Visible = true;
                radioButtonRecruit.Enabled = true;
                radioButtonVeteran.Enabled = true;
                radioButtonHardened.Enabled = true;
            }
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            timerShooter.Start();
            timerTijd.Start();
            tijdover = 15;
            totaal = 0;

            buttonStart.Visible = false;
            buttonStop.Visible = true;
            imageSus.Visible = true;

            labelScoreOut.Text = totaal.ToString();
            radioButtonHardened.Enabled = false;
            radioButtonRecruit.Enabled = false;
            radioButtonVeteran.Enabled = false;
        }

        double tijdover = 15;

        private void buttonStop_Click(object sender, EventArgs e)
        {
            timerShooter.Stop();
            timerTijd.Stop();
            tijdover = 0;
            totaal = 0;

            buttonStart.Visible = true;
            buttonStop.Visible = false;
            imageSus.Visible = false;

            labelTimeLeftOut.Text = "Game stopped!";
            pictureBackground.Visible = true;
            timerShooter.Enabled = true;

            labelScoreOut.Text = totaal.ToString();
            radioButtonRecruit.Enabled = true;
            radioButtonVeteran.Enabled = true;
            radioButtonHardened.Enabled = true;
        }

        private void radioButtonRecruit_CheckedChanged(object sender, EventArgs e)
        {
            timerShooter.Interval = 5000;
        }

        private void radioButtonHardened_CheckedChanged(object sender, EventArgs e)
        {
            timerShooter.Interval = 3000;
        }

        private void radioButtonVeteran_CheckedChanged(object sender, EventArgs e)
        {
            timerShooter.Interval = 400;
        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void labelHighscore_Click(object sender, EventArgs e)
        {

        }

        private void labelscoregetal_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
