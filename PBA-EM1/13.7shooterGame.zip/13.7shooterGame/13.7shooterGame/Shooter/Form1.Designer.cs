﻿namespace Shooter
{
    partial class ShooterGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonStop = new System.Windows.Forms.Button();
            this.radioButtonVeteran = new System.Windows.Forms.RadioButton();
            this.radioButtonHardened = new System.Windows.Forms.RadioButton();
            this.radioButtonRecruit = new System.Windows.Forms.RadioButton();
            this.labelTimeLeftOut = new System.Windows.Forms.Label();
            this.labelHighscoreOut = new System.Windows.Forms.Label();
            this.labelScoreOut = new System.Windows.Forms.Label();
            this.labelTimeLeft = new System.Windows.Forms.Label();
            this.labelHighscore = new System.Windows.Forms.Label();
            this.labelScore = new System.Windows.Forms.Label();
            this.labelDiff = new System.Windows.Forms.Label();
            this.buttonStart = new System.Windows.Forms.Button();
            this.imageSus = new System.Windows.Forms.PictureBox();
            this.pictureBackground = new System.Windows.Forms.PictureBox();
            this.timerShooter = new System.Windows.Forms.Timer(this.components);
            this.timerTijd = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imageSus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBackground)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.buttonStop);
            this.groupBox1.Controls.Add(this.radioButtonVeteran);
            this.groupBox1.Controls.Add(this.radioButtonHardened);
            this.groupBox1.Controls.Add(this.radioButtonRecruit);
            this.groupBox1.Controls.Add(this.labelTimeLeftOut);
            this.groupBox1.Controls.Add(this.labelHighscoreOut);
            this.groupBox1.Controls.Add(this.labelScoreOut);
            this.groupBox1.Controls.Add(this.labelTimeLeft);
            this.groupBox1.Controls.Add(this.labelHighscore);
            this.groupBox1.Controls.Add(this.labelScore);
            this.groupBox1.Controls.Add(this.labelDiff);
            this.groupBox1.Controls.Add(this.buttonStart);
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(936, 128);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Shooter Game";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // buttonStop
            // 
            this.buttonStop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonStop.AutoSize = true;
            this.buttonStop.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonStop.Font = new System.Drawing.Font("Stencil", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonStop.ForeColor = System.Drawing.Color.White;
            this.buttonStop.Location = new System.Drawing.Point(820, 17);
            this.buttonStop.Name = "buttonStop";
            this.buttonStop.Size = new System.Drawing.Size(110, 105);
            this.buttonStop.TabIndex = 14;
            this.buttonStop.Text = "Stop";
            this.buttonStop.UseVisualStyleBackColor = false;
            this.buttonStop.Visible = false;
            this.buttonStop.Click += new System.EventHandler(this.buttonStop_Click);
            // 
            // radioButtonVeteran
            // 
            this.radioButtonVeteran.AutoSize = true;
            this.radioButtonVeteran.Location = new System.Drawing.Point(147, 86);
            this.radioButtonVeteran.Name = "radioButtonVeteran";
            this.radioButtonVeteran.Size = new System.Drawing.Size(91, 24);
            this.radioButtonVeteran.TabIndex = 13;
            this.radioButtonVeteran.TabStop = true;
            this.radioButtonVeteran.Text = "Veteran";
            this.radioButtonVeteran.UseVisualStyleBackColor = true;
            this.radioButtonVeteran.CheckedChanged += new System.EventHandler(this.radioButtonVeteran_CheckedChanged);
            // 
            // radioButtonHardened
            // 
            this.radioButtonHardened.AutoSize = true;
            this.radioButtonHardened.Location = new System.Drawing.Point(147, 56);
            this.radioButtonHardened.Name = "radioButtonHardened";
            this.radioButtonHardened.Size = new System.Drawing.Size(105, 24);
            this.radioButtonHardened.TabIndex = 12;
            this.radioButtonHardened.TabStop = true;
            this.radioButtonHardened.Text = "Hardened";
            this.radioButtonHardened.UseVisualStyleBackColor = true;
            this.radioButtonHardened.CheckedChanged += new System.EventHandler(this.radioButtonHardened_CheckedChanged);
            // 
            // radioButtonRecruit
            // 
            this.radioButtonRecruit.AutoSize = true;
            this.radioButtonRecruit.Checked = true;
            this.radioButtonRecruit.Location = new System.Drawing.Point(147, 26);
            this.radioButtonRecruit.Name = "radioButtonRecruit";
            this.radioButtonRecruit.Size = new System.Drawing.Size(85, 24);
            this.radioButtonRecruit.TabIndex = 11;
            this.radioButtonRecruit.TabStop = true;
            this.radioButtonRecruit.Text = "Recruit";
            this.radioButtonRecruit.UseVisualStyleBackColor = true;
            this.radioButtonRecruit.CheckedChanged += new System.EventHandler(this.radioButtonRecruit_CheckedChanged);
            // 
            // labelTimeLeftOut
            // 
            this.labelTimeLeftOut.AutoSize = true;
            this.labelTimeLeftOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTimeLeftOut.Location = new System.Drawing.Point(634, 26);
            this.labelTimeLeftOut.Name = "labelTimeLeftOut";
            this.labelTimeLeftOut.Size = new System.Drawing.Size(26, 29);
            this.labelTimeLeftOut.TabIndex = 10;
            this.labelTimeLeftOut.Text = "0";
            this.labelTimeLeftOut.Click += new System.EventHandler(this.label3_Click);
            // 
            // labelHighscoreOut
            // 
            this.labelHighscoreOut.AutoSize = true;
            this.labelHighscoreOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHighscoreOut.Location = new System.Drawing.Point(422, 26);
            this.labelHighscoreOut.Name = "labelHighscoreOut";
            this.labelHighscoreOut.Size = new System.Drawing.Size(26, 29);
            this.labelHighscoreOut.TabIndex = 9;
            this.labelHighscoreOut.Text = "0";
            this.labelHighscoreOut.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // labelScoreOut
            // 
            this.labelScoreOut.AutoSize = true;
            this.labelScoreOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelScoreOut.Location = new System.Drawing.Point(358, 71);
            this.labelScoreOut.Name = "labelScoreOut";
            this.labelScoreOut.Size = new System.Drawing.Size(26, 29);
            this.labelScoreOut.TabIndex = 7;
            this.labelScoreOut.Text = "0";
            this.labelScoreOut.Click += new System.EventHandler(this.labelscoregetal_Click);
            // 
            // labelTimeLeft
            // 
            this.labelTimeLeft.AutoSize = true;
            this.labelTimeLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTimeLeft.Location = new System.Drawing.Point(504, 26);
            this.labelTimeLeft.Name = "labelTimeLeft";
            this.labelTimeLeft.Size = new System.Drawing.Size(123, 29);
            this.labelTimeLeft.TabIndex = 6;
            this.labelTimeLeft.Text = "Time left:";
            // 
            // labelHighscore
            // 
            this.labelHighscore.AutoSize = true;
            this.labelHighscore.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHighscore.Location = new System.Drawing.Point(261, 26);
            this.labelHighscore.Name = "labelHighscore";
            this.labelHighscore.Size = new System.Drawing.Size(150, 29);
            this.labelHighscore.TabIndex = 5;
            this.labelHighscore.Text = "High Score:";
            this.labelHighscore.Click += new System.EventHandler(this.labelHighscore_Click);
            // 
            // labelScore
            // 
            this.labelScore.AutoSize = true;
            this.labelScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelScore.Location = new System.Drawing.Point(261, 71);
            this.labelScore.Name = "labelScore";
            this.labelScore.Size = new System.Drawing.Size(89, 29);
            this.labelScore.TabIndex = 4;
            this.labelScore.Text = "Score:";
            this.labelScore.Click += new System.EventHandler(this.label2_Click);
            // 
            // labelDiff
            // 
            this.labelDiff.AutoSize = true;
            this.labelDiff.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDiff.Location = new System.Drawing.Point(15, 48);
            this.labelDiff.Name = "labelDiff";
            this.labelDiff.Size = new System.Drawing.Size(119, 29);
            this.labelDiff.TabIndex = 3;
            this.labelDiff.Text = "Difficulty:";
            this.labelDiff.Click += new System.EventHandler(this.label1_Click);
            // 
            // buttonStart
            // 
            this.buttonStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonStart.AutoSize = true;
            this.buttonStart.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonStart.Font = new System.Drawing.Font("Stencil", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonStart.ForeColor = System.Drawing.Color.White;
            this.buttonStart.Location = new System.Drawing.Point(820, 17);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(110, 105);
            this.buttonStart.TabIndex = 0;
            this.buttonStart.Text = "Start";
            this.buttonStart.UseVisualStyleBackColor = false;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // imageSus
            // 
            this.imageSus.BackgroundImage = global::Shooter.Properties.Resources.sus;
            this.imageSus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.imageSus.Location = new System.Drawing.Point(21, 151);
            this.imageSus.Name = "imageSus";
            this.imageSus.Size = new System.Drawing.Size(75, 77);
            this.imageSus.TabIndex = 3;
            this.imageSus.TabStop = false;
            this.imageSus.Visible = false;
            this.imageSus.Click += new System.EventHandler(this.SusClick);
            // 
            // pictureBackground
            // 
            this.pictureBackground.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBackground.Image = global::Shooter.Properties.Resources.bg;
            this.pictureBackground.Location = new System.Drawing.Point(0, 0);
            this.pictureBackground.Name = "pictureBackground";
            this.pictureBackground.Size = new System.Drawing.Size(936, 555);
            this.pictureBackground.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBackground.TabIndex = 2;
            this.pictureBackground.TabStop = false;
            this.pictureBackground.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // timerShooter
            // 
            this.timerShooter.Interval = 900;
            this.timerShooter.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timerTijd
            // 
            this.timerTijd.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // ShooterGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(936, 555);
            this.Controls.Add(this.imageSus);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBackground);
            this.MinimumSize = new System.Drawing.Size(800, 400);
            this.Name = "ShooterGame";
            this.Text = "Shooter";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imageSus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBackground)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label labelDiff;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.PictureBox pictureBackground;
        private System.Windows.Forms.Label labelTimeLeft;
        private System.Windows.Forms.Label labelHighscore;
        private System.Windows.Forms.Label labelScore;
        private System.Windows.Forms.PictureBox imageSus;
        private System.Windows.Forms.Label labelScoreOut;
        private System.Windows.Forms.Timer timerShooter;
        private System.Windows.Forms.Label labelTimeLeftOut;
        private System.Windows.Forms.Label labelHighscoreOut;
        private System.Windows.Forms.RadioButton radioButtonVeteran;
        private System.Windows.Forms.RadioButton radioButtonHardened;
        private System.Windows.Forms.RadioButton radioButtonRecruit;
        private System.Windows.Forms.Button buttonStop;
        private System.Windows.Forms.Timer timerTijd;
    }
}

