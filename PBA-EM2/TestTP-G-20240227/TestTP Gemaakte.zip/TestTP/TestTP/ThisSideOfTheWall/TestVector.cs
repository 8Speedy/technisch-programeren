﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;

namespace TestTP
{
    class TestVector
    {
        public int id { get; set; }
        public uint exerciseid { get; set; }
        public uint type { get; set; }
        public object data { get; set; }
    }
}
