﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestTP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitializeThisSide();
        }
        public double berekenOefening1(List<int> input)
        {
            int uitwerking = 0;
            int count = input.Count();

            if (count == 0) 
            { 
                uitwerking = 1;
            }
            if (count == 1)
            {
                uitwerking = 100;
            }
            if (count > 1 )
            {
                double gemmidelde = input.Average();
                double gemmidelde2 = gemmidelde + count;
                double verschil = Math.Abs(input[0] - gemmidelde2);
                double kleintste = input[0];

                for (int positie = 1; positie < count; positie++)
                {
                    verschil = Math.Abs(input[positie] - gemmidelde2);
                    if (verschil < kleintste)
                    {
                        kleintste = verschil;
                        uitwerking = input[positie];
                    }
                }
            }

            double resultaat = uitwerking;

            return resultaat;
        }

        public List<int> berekenOefening2(List<int> input)
        {
            List<int> resultaat = new List<int>();

            //if (input < 10) { input * 5; };

            return resultaat;
        }

        public List<int> berekenOefening3(int input)
        {
            List<int> resultaat = new List<int>();

            int aantal = 0;
            int getal = 0;

            int count = resultaat.Count();

            if (count == 0)
            {
                resultaat.Clear();
                resultaat.Add(-1);
                resultaat.Add(0);
                resultaat.Add(1);
            }
            else
            {
                for (int i = 1; i <= getal; i++)
                {
                    int Rest = getal % i;
                    if (Rest == 0)
                    {
                        aantal = aantal + 1;
                    }
                }
                if (aantal == 2)
                {
                    return resultaat;
                }
                else
                {
                    List<int> uitwerking = new List<int>();

                    uitwerking.Add(getal);
                }
            }
            return resultaat;
        }
    }
}
